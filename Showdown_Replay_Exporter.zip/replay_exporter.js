'use strict';

function addExportButton() {
    // 等待页面动态内容加载
    const checkExporterReady = setInterval(() => {
        const targetElement = document.querySelector('.main h1');
        if (targetElement && !document.querySelector('.export-replay-button')) {
            clearInterval(checkExporterReady); // 找到元素后停止检查

            let exportButton = document.createElement('button');
            exportButton.innerHTML = '复制所有回放链接'; // 默认中文
            exportButton.className = 'export-replay-button';
            exportButton.id = 'export-btn-onpage';
            targetElement.appendChild(exportButton);

            exportButton.addEventListener('click', () => {
                const linkElements = document.querySelectorAll('ul.linklist a.blocklink');
                const links = Array.from(linkElements).map(a => a.href);
                const linksText = links.join('\n');

                navigator.clipboard.writeText(linksText).then(() => {
                    exportButton.innerHTML = `已复制 ${links.length} 条!`;
                    setTimeout(() => {
                        exportButton.innerHTML = '复制所有回放链接';
                    }, 2000);
                });
            });
        }
    }, 500);
    setTimeout(() => clearInterval(checkExporterReady), 10000);
}

// 首次运行时注入脚本
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0].url.startsWith("https://replay.pokemonshowdown.com")) {
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: addExportButton
        });
    }
});