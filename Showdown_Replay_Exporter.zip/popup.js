'use strict';

// --- 语言翻译数据 ---
const translations = {
    'en': {
        'title': 'Replay Link Exporter',
        'copy_current': 'Copy Current Page Links',
        'copy_all': 'Copy All Pages Links',
        'lang_en': 'EN',
        'lang_zh': 'ZH',
        'status_grabbing': 'Grabbing...',
        'status_copied_part': 'Copied',
        'status_links_part': 'links!',
        'status_not_found': 'No replay links found.',
        'status_copy_failed': 'Copy failed!',
        'status_grabbing_page': 'Grabbing page',
        'status_finished_part': 'Finished! Copied a total of'
    },
    'zh': {
        'title': '回放链接导出工具',
        'copy_current': '复制当前页链接',
        'copy_all': '一键复制所有页链接',
        'lang_en': '英',
        'lang_zh': '中',
        'status_grabbing': '正在抓取...',
        'status_copied_part': '成功复制',
        'status_links_part': '条链接！',
        'status_not_found': '未找到回放链接。',
        'status_copy_failed': '复制失败！',
        'status_grabbing_page': '正在抓取第',
        'status_finished_part': '抓取完成！共复制'
    }
};

// --- DOM 元素 ---
const statusElement = document.getElementById('status');
const exportCurrentButton = document.getElementById('exportCurrentButton');
const exportAllButton = document.getElementById('exportAllButton');
const languageToggle = document.getElementById('languageToggle');

let currentLang = 'zh'; // 默认语言

// --- 核心功能函数 ---

// 此函数将被注入到网页中执行，用于抓取链接
function extractReplayLinks() {
    const linkElements = document.querySelectorAll('ul.linklist a.blocklink');
    return Array.from(linkElements).map(a => a.href);
}

// 更新界面文本
function setLanguage(lang) {
    currentLang = lang;
    document.querySelectorAll('[data-lang-key]').forEach(elem => {
        const key = elem.getAttribute('data-lang-key');
        elem.textContent = translations[lang][key];
    });
    languageToggle.checked = lang === 'zh';
}

function updateStatus(key, details = '') {
    const text = translations[currentLang][key] || key;
    statusElement.textContent = `${text} ${details}`;
}

// --- 事件监听器 ---

// 复制当前页
exportCurrentButton.addEventListener('click', async () => {
    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    updateStatus('status_grabbing');
    try {
        const results = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            function: extractReplayLinks,
        });
        const links = results[0].result;
        if (links && links.length > 0) {
            await navigator.clipboard.writeText(links.join('\n'));
            updateStatus('status_copied_part', `${links.length} ${translations[currentLang]['status_links_part']}`);
        } else {
            updateStatus('status_not_found');
        }
    } catch (e) {
        updateStatus('status_copy_failed');
    }
});

// 复制所有页
exportAllButton.addEventListener('click', async () => {
    exportCurrentButton.disabled = true;
    exportAllButton.disabled = true;

    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const originalUrl = tab.url;
    let baseUrl = originalUrl.split('&page=')[0];
    let currentPage = 1;
    let allLinks = [];

    while (true) {
        updateStatus('status_grabbing_page', `${currentPage}...`);
        
        // 构建当前页面的URL
        const url = currentPage === 1 ? baseUrl : `${baseUrl}&page=${currentPage}`;
        
        // 更新标签页URL并等待加载完成
        await chrome.tabs.update(tab.id, { url });
        await new Promise(resolve => {
            const listener = (tabId, changeInfo) => {
                if (tabId === tab.id && changeInfo.status === 'complete') {
                    chrome.tabs.onUpdated.removeListener(listener);
                    // 稍作延迟，确保页面JS执行完毕
                    setTimeout(resolve, 500);
                }
            };
            chrome.tabs.onUpdated.addListener(listener);
        });

        // 执行脚本抓取链接
        const results = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            function: extractReplayLinks,
        });

        const newLinks = results[0].result;
        if (!newLinks || newLinks.length === 0) {
            // 如果没有链接，说明是最后一页，结束循环
            break;
        }

        allLinks.push(...newLinks);
        currentPage++;
    }

    // 将所有链接复制到剪贴板
    if (allLinks.length > 0) {
        await navigator.clipboard.writeText(allLinks.join('\n'));
        updateStatus('status_finished_part', `${allLinks.length} ${translations[currentLang]['status_links_part']}`);
    } else {
        updateStatus('status_not_found');
    }

    // （可选）操作结束后，可以导航回第一页
    // await chrome.tabs.update(tab.id, { url: originalUrl.split('&page=')[0] });

    exportCurrentButton.disabled = false;
    exportAllButton.disabled = false;
});


// 语言切换
languageToggle.addEventListener('change', (event) => {
    const lang = event.target.checked ? 'zh' : 'en';
    chrome.storage.local.set({ language: lang }, () => {
        setLanguage(lang);
    });
});

// 初始化：加载保存的语言设置
chrome.storage.local.get('language', (data) => {
    setLanguage(data.language || 'zh');
});